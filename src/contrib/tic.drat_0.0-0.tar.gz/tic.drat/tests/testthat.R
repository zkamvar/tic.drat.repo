library(testthat)
library(tic.drat)

test_check("tic.drat")
